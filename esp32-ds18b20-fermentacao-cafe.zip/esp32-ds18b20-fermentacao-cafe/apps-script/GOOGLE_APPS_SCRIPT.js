// ============================================================
// GOOGLE APPS SCRIPT
// Recebe dados do ESP32 e grava na planilha
// Cada dia é uma aba separada
// A cada envio, limpa a aba e reescreve tudo do CSV
// ============================================================

function doGet(e) {

  var params  = e.parameter;
  var data    = params.data    || ""; // Data no formato DD-MM-YYYY
  var horario = params.horario || ""; // Horário no formato HH:MM:SS
  var linha   = parseInt(params.linha) || 0; // Índice da linha (1, 2, 3...)

  // ----------------------------------------------------------
  // Abre a planilha ativa e busca a aba do dia
  // ----------------------------------------------------------
  var ss    = SpreadsheetApp.getActiveSpreadsheet();
  var sheet = ss.getSheetByName(data); // Aba com nome = data do dia

  // Cria a aba se não existir
  if (!sheet) {
    sheet = ss.insertSheet(data);
  }

  // ----------------------------------------------------------
  // Se for a primeira linha de dados (linha == 1)
  // limpa a aba e recria o cabeçalho
  // Isso garante que a aba sempre reflete exatamente o CSV
  // ----------------------------------------------------------
  if (linha === 1) {
    sheet.clearContents(); // Apaga todos os dados da aba
    sheet.appendRow([      // Recria o cabeçalho
      "Horario",
      "Sensor 1",  "Sensor 2",  "Sensor 3",
      "Sensor 4",  "Sensor 5",  "Sensor 6",
      "Sensor 7",  "Sensor 8",  "Sensor 9",
      "Sensor 10"
    ]);
  }

  // ----------------------------------------------------------
  // Monta a linha de dados: horario + 10 temperaturas
  // ----------------------------------------------------------
  var row = [horario]; // Primeira coluna: horário

  for (var i = 1; i <= 10; i++) {
    var val = params["s" + i]; // s1, s2, ... s10

    if (val === undefined || val === "") {
      row.push("---"); // Dado ausente
    }
    else if (val === "ERRO") {
      row.push("ERRO"); // Sensor com falha
    }
    else {
      row.push(parseFloat(val)); // Temperatura numérica
    }
  }

  // Grava a linha na aba
  sheet.appendRow(row);

  // Retorna confirmação com detalhes do que foi gravado
  return ContentService.createTextOutput(
    "OK | aba: " + data +
    " | linha: " + linha +
    " | horario: " + horario
  );
}
