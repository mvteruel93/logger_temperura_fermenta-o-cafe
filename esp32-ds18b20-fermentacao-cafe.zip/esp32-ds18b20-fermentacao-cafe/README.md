# Logger de temperatura com ESP32 e DS18B20 para fermentação anaeróbica de café

Firmware e script de integração do sistema embarcado desenvolvido no Trabalho de Conclusão de Curso
**"Sistema embarcado com ESP32 para monitoramento automático da temperatura em fermentação anaeróbica de café"**
(Engenharia Agrícola e Ambiental, ICA/UFMG, Campus Montes Claros, 2026).

O sistema lê 10 sensores DS18B20 a cada 10 minutos, grava os dados em CSV no cartão microSD e, havendo Wi-Fi,
sincroniza-os com o Google Sheets. Alertas de falha são enviados pelo Telegram.

## Estrutura

```
firmware/LOGGER_TEMPERATURA_FINAL/
  LOGGER_TEMPERATURA_FINAL.ino   firmware do ESP32 (versão usada no ensaio)
  secrets.example.h              modelo de credenciais (copiar para secrets.h)
apps-script/
  GOOGLE_APPS_SCRIPT.js          script que recebe os dados e grava na planilha
```

## Hardware

| Item | Observação |
|---|---|
| ESP32 DevKit V1 | alimentação por USB, 5 V |
| 10 × DS18B20 (encapsulamento impermeável, cabo de 2 m) | 5 sensores em cada barramento 1-Wire |
| 2 × resistor de 4,7 kΩ | pull-up da linha de dados de cada barramento |
| Módulo leitor de cartão microSD (SPI) | cartão formatado em FAT |
| Módulo RTC DS3231 (I2C) | reserva quando o NTP não está disponível |
| LCD 16 × 2 com interface I2C (endereço 0x27) | mostra data/hora e um sensor por vez |

### Pinagem

| Função | GPIO |
|---|---|
| 1-Wire, barramento 1 (sensores 1 a 5) | 4 |
| 1-Wire, barramento 2 (sensores 6 a 10) | 5 |
| I2C SDA (LCD e DS3231) | 27 |
| I2C SCL (LCD e DS3231) | 26 |
| SD — SCK | 22 |
| SD — CS | 21 |
| SD — MOSI | 19 |
| SD — MISO | 18 |

## Ambiente de compilação

- Arduino IDE 2.3.9
- Pacote de placas **esp32 (Espressif Systems) 3.0.7**; placa selecionada: _DOIT ESP32 DEVKIT V1_ (ou _ESP32 Dev Module_)
- Bibliotecas instaladas pelo Gerenciador de Bibliotecas:

| Biblioteca | Versão |
|---|---|
| OneWire | _preencher_ |
| DallasTemperature | _preencher_ |
| RTClib (Adafruit) | _preencher_ |
| LiquidCrystal_I2C (indicar o autor/fork) | _preencher_ |

- Bibliotecas que acompanham o pacote de placas (versão 3.0.7): SPI, SD, Wire, WiFi, WiFiClientSecure, HTTPClient e time.

## Configuração

1. **Credenciais.** Na pasta do sketch, copie `secrets.example.h` para `secrets.h` e preencha Wi-Fi, token e ID do chat do
   Telegram e a URL do Apps Script. O `secrets.h` está no `.gitignore` e não deve ser publicado.
2. **Planilha e Apps Script.** Crie uma planilha no Google Sheets, abra _Extensões → Apps Script_ a partir dela, cole o
   conteúdo de `apps-script/GOOGLE_APPS_SCRIPT.js` e use _Implantar → Nova implantação → App da Web_
   (executar como: você; acesso: qualquer pessoa). Copie a URL terminada em `/exec` para `GOOGLE_SCRIPT_URL`.
   O script usa a planilha ativa e cria uma aba por dia, com o nome `DD-MM-AAAA`.
3. **Telegram.** Crie um bot com o `@BotFather` (gera o `BOT_TOKEN`) e obtenha o `CHAT_ID` do chat que receberá os alertas.
4. **Endereços dos sensores.** Cada DS18B20 tem um endereço único de 8 bytes, declarado em `sensor1` a `sensor10` no
   `.ino` (sensores 1 a 5 no barramento do GPIO 4; 6 a 10 no do GPIO 5). Substitua pelos endereços dos seus sensores
   (por exemplo, com o exemplo _oneWireSearch_ da biblioteca DallasTemperature).
5. Compile e envie o sketch para a placa.

## Funcionamento

- **Leitura.** A cada 10 minutos (a primeira ocorre 10 minutos após a inicialização) os 10 sensores são lidos e uma linha é
  gravada no CSV do dia. O firmware não chama `setResolution()`: cada sensor opera com a resolução gravada em sua própria EEPROM.
- **Hora.** NTP (`pool.ntp.org`, UTC−3) como fonte principal; o DS3231 é ajustado pelo NTP na inicialização e usado como
  reserva se o NTP não estiver disponível.
- **Armazenamento.** Um arquivo por dia, `/AAAA-MM-DD.csv`, separador `;`, ponto decimal, cabeçalho
  `Horario;Sensor 1;...;Sensor 10` e linhas `HH:MM:SS;t1;...;t10`. Leituras desconectadas (−127 °C) ou fora de −50 a 125 °C
  são gravadas como `ERRO`. O valor 85,00 °C (valor de reinício do DS18B20) **não** é filtrado pelo firmware e deve ser
  tratado na análise.
- **Sincronização.** Com Wi-Fi, o CSV do dia é reenviado ao Apps Script linha a linha (uma requisição HTTP GET por linha);
  o script apaga e reescreve a aba do dia a cada sincronização.
- **Alertas no Telegram.** Inicialização, cartão SD ausente/removido/reconectado, reconexão do Wi-Fi e falha de sensor.
- **LCD.** Linha 1: data e hora; linha 2: temperatura de um sensor, trocando a cada 5 s.
- **Cartão SD ausente na inicialização** interrompe o firmware (o SD é obrigatório).

## Limitações conhecidas

- A cada ciclo o CSV do dia inteiro é reenviado; o tempo de sincronização cresce ao longo do dia e bloqueia o laço principal
  enquanto dura.
- As conexões HTTPS usam `setInsecure()` (o certificado do servidor não é validado).
- As credenciais ficam em texto simples em `secrets.h`; use rede e bot dedicados ao experimento.

## Como citar

Os metadados de citação estão em [`CITATION.cff`](CITATION.cff) (o GitHub exibe o botão _Cite this repository_).

## Licença

[MIT](LICENSE).
