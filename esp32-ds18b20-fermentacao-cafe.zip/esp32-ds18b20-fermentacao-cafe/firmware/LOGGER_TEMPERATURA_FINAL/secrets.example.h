// ============================================================
// secrets.example.h — MODELO de credenciais
//
// 1. Copie este arquivo para "secrets.h" (mesma pasta do .ino).
// 2. Preencha os valores abaixo.
// 3. NUNCA publique o secrets.h (ele está no .gitignore).
// ============================================================
#pragma once

// WiFi
const char* ssid     = "NOME_DA_REDE_WIFI";
const char* password = "SENHA_DA_REDE_WIFI";

// Telegram (bot criado com o BotFather)
const char* BOT_TOKEN = "TOKEN_DO_BOT_TELEGRAM";
const char* CHAT_ID   = "ID_DO_CHAT_TELEGRAM";

// Google Apps Script (URL da implantação como "App da Web", termina em /exec)
const char* GOOGLE_SCRIPT_URL =
  "https://script.google.com/macros/s/SEU_ID_DE_IMPLANTACAO/exec";
