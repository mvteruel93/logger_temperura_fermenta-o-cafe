// ============================================================
// LOGGER_TEMPERATURA_FINAL.ino
// ESP32 DevKit V1
// Lê 10 sensores DS18B20 a cada 10 minutos
// Grava no CSV do SD, sincroniza com Google Sheets via CSV
// LCD I2C 16x2 (0x27) | RTC DS3231 | Telegram
// ============================================================

// ------------------------------------------------------------
// BIBLIOTECAS
// ------------------------------------------------------------
#include <OneWire.h>           // Protocolo 1-Wire para sensores DS18B20
#include <DallasTemperature.h> // Leitura de temperatura DS18B20
#include <SPI.h>               // Comunicação SPI (cartão SD)
#include <SD.h>                // Leitura e escrita no cartão SD
#include <WiFi.h>              // Conexão WiFi do ESP32
#include <WiFiClientSecure.h>  // Cliente HTTPS com SSL
#include <HTTPClient.h>        // Requisições HTTP/HTTPS
#include <time.h>              // Data e hora via NTP
#include <Wire.h>              // Comunicação I2C (LCD e RTC)
#include <LiquidCrystal_I2C.h> // Controle do LCD via I2C
#include <RTClib.h>            // Controle do RTC DS3231
#include "secrets.h"       // Credenciais e URLs (copie secrets.example.h -> secrets.h)

// ------------------------------------------------------------
// WIFI
// ------------------------------------------------------------
// ssid e password: definidos em secrets.h

// ------------------------------------------------------------
// TELEGRAM
// ------------------------------------------------------------
// BOT_TOKEN: definido em secrets.h
// CHAT_ID: definido em secrets.h

// ------------------------------------------------------------
// GOOGLE SHEETS
// URL do Apps Script que recebe os dados e grava na planilha
// ------------------------------------------------------------
// GOOGLE_SCRIPT_URL: definido em secrets.h

// ------------------------------------------------------------
// NTP — Sincronização de hora pela internet
// ------------------------------------------------------------
const char* ntpServer          = "pool.ntp.org"; // Servidor de hora
const long  gmtOffset_sec      = -10800;          // UTC-3 (Brasília)
const int   daylightOffset_sec = 0;               // Sem horário de verão

// ------------------------------------------------------------
// LCD I2C 16x2
// Endereço 0x27, 16 colunas, 2 linhas
// ------------------------------------------------------------
LiquidCrystal_I2C lcd(0x27, 16, 2);

// ------------------------------------------------------------
// RTC DS3231
// Relógio de tempo real usado como backup do NTP
// ------------------------------------------------------------
RTC_DS3231 rtc;
bool rtcDisponivel = false; // Flag: RTC encontrado e funcionando

// ------------------------------------------------------------
// PINOS DO CARTÃO SD (barramento SPI)
// ------------------------------------------------------------
#define SD_SCK   22 // Clock SPI
#define SD_CS    21 // Chip Select do SD
#define SD_MOSI  19 // Dados: ESP32 → SD
#define SD_MISO  18 // Dados: SD → ESP32

File dataFile; // Objeto de arquivo para gravar no SD

// ------------------------------------------------------------
// BARRAMENTO 1 DOS SENSORES — GPIO 4
// Sensores 1 a 5
// ------------------------------------------------------------
#define BUS_1 4
OneWire oneWire1(BUS_1);              // Barramento 1-Wire no GPIO 4
DallasTemperature sensors1(&oneWire1); // Gerenciador dos sensores do BUS 1

// ------------------------------------------------------------
// BARRAMENTO 2 DOS SENSORES — GPIO 5
// Sensores 6 a 10
// ------------------------------------------------------------
#define BUS_2 5
OneWire oneWire2(BUS_2);              // Barramento 1-Wire no GPIO 5
DallasTemperature sensors2(&oneWire2); // Gerenciador dos sensores do BUS 2

// ------------------------------------------------------------
// ENDEREÇOS DOS SENSORES — BUS 1
// Cada DS18B20 tem endereço único de 8 bytes gravado de fábrica
// ------------------------------------------------------------
DeviceAddress sensor1  = {0x28, 0x86, 0x25, 0xBA, 0x00, 0x00, 0x00, 0xE6};
DeviceAddress sensor2  = {0x28, 0x31, 0xF0, 0xB4, 0x00, 0x00, 0x00, 0xFD};
DeviceAddress sensor3  = {0x28, 0x43, 0x72, 0xB2, 0x00, 0x00, 0x00, 0x4A};
DeviceAddress sensor4  = {0x28, 0x67, 0x64, 0xB2, 0x00, 0x00, 0x00, 0xC0};
DeviceAddress sensor5  = {0x28, 0x37, 0x4A, 0xB3, 0x00, 0x00, 0x00, 0x3B};

// ------------------------------------------------------------
// ENDEREÇOS DOS SENSORES — BUS 2
// ------------------------------------------------------------
DeviceAddress sensor6  = {0x28, 0x30, 0x3D, 0xBA, 0x00, 0x00, 0x00, 0x11};
DeviceAddress sensor7  = {0x28, 0x89, 0xEA, 0xB4, 0x00, 0x00, 0x00, 0x9A};
DeviceAddress sensor8  = {0x28, 0x59, 0x88, 0xB9, 0x00, 0x00, 0x00, 0x51};
DeviceAddress sensor9  = {0x28, 0xD5, 0xE8, 0xB4, 0x00, 0x00, 0x00, 0x4A};
DeviceAddress sensor10 = {0x28, 0xFB, 0x93, 0xBA, 0x00, 0x00, 0x00, 0xE7};

// ------------------------------------------------------------
// CONTROLE DE TEMPO
// ------------------------------------------------------------
unsigned long tempoLeitura           = 0;      // Momento da última leitura
const unsigned long intervaloLeitura = 600000; // Intervalo: 10 minutos em ms

unsigned long tempoDisplay           = 0;      // Momento da última atualização do LCD
const unsigned long intervaloDisplay = 5000;   // Troca de sensor no LCD: 5 segundos
int sensorDisplay                    = 0;      // Índice do sensor exibido no LCD

// ------------------------------------------------------------
// NUMERO DE SENSORES
// ------------------------------------------------------------
#define NUM_SENSORES 10

// ------------------------------------------------------------
// ESTADO DO WIFI
// Rastreia mudanças para detectar reconexão
// ------------------------------------------------------------
bool wifiConectado = false;

// ------------------------------------------------------------
// ESTADO DO CARTÃO SD
// Rastreia remoção e reinserção do cartão
// ------------------------------------------------------------
bool sdDisponivel = false; // Flag: SD montado e funcionando

// ------------------------------------------------------------
// ÚLTIMAS TEMPERATURAS LIDAS
// Compartilhado entre leitura e exibição no LCD
// ------------------------------------------------------------
float ultimasTemps[NUM_SENSORES]; // Array com temperatura de cada sensor
bool  primeiraLeitura = true;     // True até a primeira leitura ser feita

// ============================================================
// SETUP — Executado uma vez ao ligar
// ============================================================

void setup() {

  Serial.begin(115200); // Inicia serial para debug
  delay(5000);          // Aguarda fonte externa estabilizar

  Serial.println();
  Serial.println("LOGGER TEMPERATURA");

  // ----------------------------------------------------------
  // I2C — SDA=GPIO27, SCL=GPIO26
  // LCD e RTC compartilham o mesmo barramento
  // ----------------------------------------------------------
  Wire.begin(27, 26);

  // ----------------------------------------------------------
  // LCD
  // ----------------------------------------------------------
  lcd.init();           // Inicializa o display
  lcd.backlight();      // Liga o backlight
  lcd.setCursor(0, 0);  // Linha 0
  lcd.print("LOGGER TEMP");
  lcd.setCursor(0, 1);  // Linha 1
  lcd.print("Iniciando...");

  // ----------------------------------------------------------
  // RTC DS3231
  // ----------------------------------------------------------
  if (rtc.begin()) {            // Tenta inicializar o RTC
    rtcDisponivel = true;        // RTC encontrado
    Serial.println("RTC OK");

    if (rtc.lostPower()) {       // Verifica se perdeu energia e a hora
      Serial.println("RTC sem hora - aguardando NTP");
    }
  }
  else {
    Serial.println("RTC nao encontrado"); // Não respondeu no I2C
  }

  // ----------------------------------------------------------
  // WIFI
  // ----------------------------------------------------------
  conectarWiFi();

  // ----------------------------------------------------------
  // NTP — configura servidor e aguarda sincronização
  // ----------------------------------------------------------
  configTime(gmtOffset_sec, daylightOffset_sec, ntpServer);

  struct tm timeinfo;   // Estrutura para armazenar data/hora
  int tentativasNTP = 0;

  while (!getLocalTime(&timeinfo) && tentativasNTP < 10) {
    delay(1000);          // Aguarda 1 segundo entre tentativas
    tentativasNTP++;
    Serial.println("Aguardando NTP...");
  }

  // Se NTP sincronizou, grava hora no RTC como referência futura
  if (getLocalTime(&timeinfo) && rtcDisponivel) {
    rtc.adjust(DateTime(timeinfo.tm_year + 1900, // Ano (tm_year = anos desde 1900)
                        timeinfo.tm_mon  + 1,    // Mês (tm_mon vai de 0 a 11)
                        timeinfo.tm_mday,         // Dia
                        timeinfo.tm_hour,         // Hora
                        timeinfo.tm_min,          // Minuto
                        timeinfo.tm_sec));        // Segundo
    Serial.println("RTC sincronizado com NTP");
  }

  // ----------------------------------------------------------
  // SENSORES DS18B20
  // ----------------------------------------------------------
  sensors1.begin(); // Inicializa sensores do BUS 1
  sensors2.begin(); // Inicializa sensores do BUS 2

  for (int i = 0; i < NUM_SENSORES; i++) {
    ultimasTemps[i] = 0.0; // Inicializa array de temperaturas
  }

  // ----------------------------------------------------------
  // CARTÃO SD
  // ----------------------------------------------------------
  SPI.begin(SD_SCK, SD_MISO, SD_MOSI, SD_CS); // Inicia barramento SPI
  delay(2000); // Aguarda SD estabilizar

  if (!SD.begin(SD_CS, SPI, 1000000)) { // Tenta montar o SD a 1MHz
    Serial.println("ERRO SD");
    lcd.clear();
    lcd.setCursor(0, 0);
    lcd.print("ERRO SD!");
    enviarTelegram("ERRO SD");
    while (1); // Trava — SD é obrigatório
  }

  sdDisponivel = true; // SD montado com sucesso
  Serial.println("SD OK");
  criarArquivoDia(); // Cria CSV do dia se não existir

  wifiConectado = (WiFi.status() == WL_CONNECTED); // Salva estado atual do WiFi

  lcd.clear();
  lcd.setCursor(0, 0);
  lcd.print("Sistema OK");

  enviarTelegram("Sistema iniciado");
  delay(2000);
}

// ============================================================
// LOOP — Executado continuamente
// ============================================================

void loop() {

  unsigned long agora = millis(); // Tempo em ms desde o boot

  // ----------------------------------------------------------
  // Monitora estado do cartão SD
  // Tenta remontar se foi retirado e reinserido
  // ----------------------------------------------------------
  bool sdAtual = SD.cardType() != CARD_NONE; // Verifica se SD está presente

  if (sdDisponivel && !sdAtual) {
    // SD foi removido
    sdDisponivel = false;
    Serial.println("SD REMOVIDO!");
    lcd.clear();
    lcd.setCursor(0, 0);
    lcd.print("ERRO: SD removido");
    enviarTelegram("AVISO: Cartao SD removido!");
  }
  else if (!sdDisponivel && sdAtual) {
    // SD foi reinserido — tenta remontar
    SD.end(); // Encerra sessão anterior
    delay(500);
    if (SD.begin(SD_CS, SPI, 1000000)) {
      sdDisponivel = true;
      Serial.println("SD reinserido e montado");
      lcd.clear();
      lcd.setCursor(0, 0);
      lcd.print("SD reconectado  ");
      enviarTelegram("SD reconectado");
      criarArquivoDia(); // Recria arquivo do dia se necessário
    }
    else {
      Serial.println("SD reinserido mas falhou ao montar");
    }
  }

  // ----------------------------------------------------------
  // Monitora mudanças no estado do WiFi
  // ----------------------------------------------------------
  bool wifiAtual = (WiFi.status() == WL_CONNECTED);

  if (!wifiConectado && wifiAtual) {
    // WiFi reconectou
    wifiConectado = true;
    Serial.println("WiFi reconectado");
    enviarTelegram("WiFi reconectado");
  }
  else if (wifiConectado && !wifiAtual) {
    // WiFi caiu
    wifiConectado = false;
    Serial.println("WiFi desconectado");
  }

  // ----------------------------------------------------------
  // Leitura a cada 10 minutos
  // ----------------------------------------------------------
  if (agora - tempoLeitura >= intervaloLeitura) {
    tempoLeitura = agora; // Atualiza marcador de tempo
    realizarLeituras();   // Lê sensores, grava SD, sincroniza Sheets
  }

  // ----------------------------------------------------------
  // Atualiza LCD a cada 5 segundos
  // ----------------------------------------------------------
  if (agora - tempoDisplay >= intervaloDisplay) {
    tempoDisplay = agora; // Atualiza marcador de tempo
    atualizarDisplay();   // Mostra data/hora e sensor atual
  }
}

// ============================================================
// OBTER DATA E HORA
// Tenta NTP; se falhar usa RTC como backup
// ============================================================

bool obterDataHora(char* data, char* horario) {

  struct tm timeinfo;

  if (getLocalTime(&timeinfo)) {
    // NTP disponível
    strftime(data,    11, "%d-%m-%Y", &timeinfo); // Ex: "09-06-2026"
    strftime(horario,  9, "%H:%M:%S", &timeinfo); // Ex: "08:00:00"
    return true;
  }

  if (rtcDisponivel) {
    // Fallback: usa RTC
    DateTime now = rtc.now();
    sprintf(data,    "%02d-%02d-%04d",
            now.day(), now.month(), now.year());   // DD-MM-YYYY
    sprintf(horario, "%02d:%02d:%02d",
            now.hour(), now.minute(), now.second()); // HH:MM:SS
    Serial.println("Usando RTC (NTP indisponivel)");
    return true;
  }

  Serial.println("ERRO: sem NTP e sem RTC");
  return false; // Nenhuma fonte de hora disponível
}

// ============================================================
// MONTAR NOME DO ARQUIVO CSV
// Converte DD-MM-YYYY → /YYYY-MM-DD.csv
// Ex: "09-06-2026" → "/2026-06-09.csv"
// ============================================================

void montarNomeArquivo(char* data, char* nomeArquivo) {
  snprintf(nomeArquivo, 30,
           "/%.4s-%.2s-%.2s.csv",
           data + 6,  // YYYY (posição 6 de "DD-MM-YYYY")
           data + 3,  // MM   (posição 3)
           data);     // DD   (posição 0)
}

// ============================================================
// ATUALIZAR LCD
// Linha 1: data e hora | Linha 2: sensor atual (troca a cada 5s)
// ============================================================

void atualizarDisplay() {

  char data[11];
  char horario[9];

  // Linha 1: data e hora
  if (!obterDataHora(data, horario)) {
    lcd.setCursor(0, 0);
    lcd.print("Sem hora        "); // 16 chars para limpar linha
  }
  else {
    char linha1[17]; // 16 chars + null terminator
    // Formato: "DD/MM/AA HH:MM:SS"
    snprintf(linha1, sizeof(linha1),
             "%.2s/%.2s/%.2s %.8s",
             data,       // DD
             data + 3,   // MM
             data + 8,   // YY (2 últimos dígitos)
             horario);   // HH:MM:SS
    lcd.setCursor(0, 0);
    lcd.print(linha1);
  }

  // Linha 2: temperatura do sensor atual
  String nomeSensor = "S" + String(sensorDisplay + 1) + ":";
  String linha2     = "";

  if (primeiraLeitura) {
    linha2 = nomeSensor + " Aguardando"; // Ainda sem leitura
  }
  else {
    float t = ultimasTemps[sensorDisplay];

    if (t == DEVICE_DISCONNECTED_C || t < -50 || t > 125) {
      linha2 = nomeSensor + " ERRO"; // Sensor com problema
    }
    else {
      char buf[8];
      dtostrf(t, 5, 1, buf);               // Float para string com 1 decimal
      linha2 = nomeSensor + String(buf) + " C"; // Ex: "S1: 25.5 C"
    }
  }

  // Preenche com espaços para apagar restos da exibição anterior
  while (linha2.length() < 16) linha2 += " ";
  lcd.setCursor(0, 1);
  lcd.print(linha2);

  // Avança para o próximo sensor (circular 0→9→0)
  sensorDisplay = (sensorDisplay + 1) % NUM_SENSORES;
}

// ============================================================
// REALIZAR LEITURAS
// Passo 1: lê sensores
// Passo 2: grava linha no CSV do SD
// Passo 3: sincroniza CSV completo com Google Sheets
// ============================================================

void realizarLeituras() {

  Serial.println();
  Serial.println("REALIZANDO LEITURAS");

  // Dispara conversão de temperatura em todos os sensores
  sensors1.requestTemperatures(); // BUS 1
  sensors2.requestTemperatures(); // BUS 2

  char data[11];
  char horario[9];

  if (!obterDataHora(data, horario)) {
    return; // Sem hora, aborta
  }

  char nomeArquivo[30];
  montarNomeArquivo(data, nomeArquivo); // Ex: "/2026-06-09.csv"

  // ----------------------------------------------------------
  // Cria arquivo CSV com cabeçalho se não existir ainda
  // ----------------------------------------------------------
  if (!SD.exists(nomeArquivo)) {
    dataFile = SD.open(nomeArquivo, FILE_WRITE); // Cria novo arquivo
    if (dataFile) {
      dataFile.print("Horario"); // Primeira coluna
      for (int i = 1; i <= NUM_SENSORES; i++) {
        dataFile.print(";Sensor "); // Separador ";"
        dataFile.print(i);          // "Sensor 1" ... "Sensor 10"
      }
      dataFile.println(); // Quebra de linha
      dataFile.close();
      Serial.print("Arquivo criado: ");
      Serial.println(nomeArquivo);
    }
    else {
      Serial.println("ERRO ao criar arquivo");
      enviarTelegram("ERRO ao criar arquivo SD");
      return;
    }
  }

  // ----------------------------------------------------------
  // Lê temperatura de todos os 10 sensores
  // ----------------------------------------------------------
  ultimasTemps[0] = sensors1.getTempC(sensor1);  // BUS 1
  ultimasTemps[1] = sensors1.getTempC(sensor2);
  ultimasTemps[2] = sensors1.getTempC(sensor3);
  ultimasTemps[3] = sensors1.getTempC(sensor4);
  ultimasTemps[4] = sensors1.getTempC(sensor5);
  ultimasTemps[5] = sensors2.getTempC(sensor6);  // BUS 2
  ultimasTemps[6] = sensors2.getTempC(sensor7);
  ultimasTemps[7] = sensors2.getTempC(sensor8);
  ultimasTemps[8] = sensors2.getTempC(sensor9);
  ultimasTemps[9] = sensors2.getTempC(sensor10);

  primeiraLeitura = false; // Marca que já houve pelo menos uma leitura

  // ----------------------------------------------------------
  // Grava nova linha no CSV: Horario;t1;t2;...;t10
  // ----------------------------------------------------------
  dataFile = SD.open(nomeArquivo, FILE_APPEND); // Abre para adicionar no final

  if (!dataFile) {
    Serial.println("ERRO ao abrir SD");
    enviarTelegram("ERRO ao abrir SD");
    return;
  }

  dataFile.print(horario); // Coluna 1: horário

  for (int i = 0; i < NUM_SENSORES; i++) {
    dataFile.print(";"); // Separador

    if (ultimasTemps[i] == DEVICE_DISCONNECTED_C ||
        ultimasTemps[i] < -50 ||
        ultimasTemps[i] > 125) {
      dataFile.print("ERRO"); // Fora do range ou desconectado
    }
    else {
      dataFile.print(ultimasTemps[i]); // Temperatura em °C
    }
  }

  dataFile.println(); // Quebra de linha
  dataFile.close();   // Fecha o arquivo — essencial para salvar

  // ----------------------------------------------------------
  // Exibe no Serial Monitor
  // ----------------------------------------------------------
  Serial.print(data);
  Serial.print(" | ");
  Serial.println(horario);

  for (int i = 0; i < NUM_SENSORES; i++) {
    String nomeSensor = "Sensor " + String(i + 1);
    if (ultimasTemps[i] == DEVICE_DISCONNECTED_C ||
        ultimasTemps[i] < -50 ||
        ultimasTemps[i] > 125) {
      Serial.print(nomeSensor);
      Serial.println(": ERRO");
      enviarTelegram("ERRO SENSOR: " + nomeSensor); // Alerta no Telegram
    }
    else {
      Serial.print(nomeSensor);
      Serial.print(": ");
      Serial.print(ultimasTemps[i]);
      Serial.println(" C");
    }
  }

  // ----------------------------------------------------------
  // Sincroniza CSV completo com Google Sheets (se WiFi ok)
  // ----------------------------------------------------------
  if (WiFi.status() == WL_CONNECTED) {
    sincronizarSheets(data, nomeArquivo);
  }
  else {
    Serial.println("WiFi offline - Sheets sera sincronizado ao reconectar");
  }

  Serial.println("--------------------------------");
}

// ============================================================
// SINCRONIZAR CSV COM GOOGLE SHEETS
// Lê todas as linhas do CSV e envia para o Apps Script
// O script limpa a aba e reescreve com os dados recebidos
// Garante que a planilha sempre reflete o SD com fidelidade
// ============================================================

void sincronizarSheets(char* data, char* nomeArquivo) {

  Serial.println("Sincronizando com Google Sheets...");

  File f = SD.open(nomeArquivo, FILE_READ); // Abre CSV para leitura

  if (!f) {
    Serial.println("ERRO ao abrir CSV para sincronizacao");
    return;
  }

  // Pula o cabeçalho (primeira linha do CSV)
  if (f.available()) {
    f.readStringUntil('\n');
  }

  int total   = 0; // Total de linhas de dados
  int enviadas = 0; // Linhas enviadas com sucesso

  while (f.available()) {

    String linha = f.readStringUntil('\n'); // Lê uma linha de dados
    linha.trim(); // Remove \r e espaços extras

    if (linha.length() < 5) continue; // Linha vazia, pula

    total++; // Conta linha válida

    // Separa os campos pelo delimitador ";"
    // Formato esperado: HH:MM:SS;t1;t2;...;t10
    String campos[12]; // Array para até 12 campos
    int idx   = 0;     // Índice do campo atual
    int start = 0;     // Posição inicial do campo na string

    for (int i = 0; i <= (int)linha.length() && idx < 12; i++) {
      if (i == (int)linha.length() || linha[i] == ';') {
        campos[idx++] = linha.substring(start, i); // Extrai campo
        start = i + 1; // Próximo campo começa após o ";"
      }
    }

    if (idx < 2) continue; // Linha com poucos campos, pula

    String horario = campos[0]; // Campo 0: horário da leitura

    // Monta URL com data, horário, índice da linha e temperaturas
    // Parâmetro "linha" permite o script posicionar corretamente
    String url = String(GOOGLE_SCRIPT_URL) +
                 "?data="    + String(data)  + // Data da aba
                 "&horario=" + horario        + // Horário da linha
                 "&linha="   + String(total);  // Índice para o script

    // Adiciona cada temperatura: &s1=25.5&s2=24.0...
    for (int i = 1; i < idx && i <= NUM_SENSORES; i++) {
      url += "&s" + String(i) + "=" + campos[i];
    }

    url.replace(" ", "%20"); // Encode de espaços na URL

    // Faz requisição HTTP GET para o Apps Script
    WiFiClientSecure client;
    client.setInsecure(); // Aceita SSL sem validar certificado
    HTTPClient http;
    http.begin(client, url);
    http.setFollowRedirects(HTTPC_STRICT_FOLLOW_REDIRECTS); // Segue redirecionamentos do Google
    int httpCode = http.GET();
    http.end(); // Encerra conexão

    if (httpCode == 200) {
      enviadas++; // Linha gravada com sucesso
    }

    Serial.print("Linha ");
    Serial.print(total);
    Serial.print(" HTTP: ");
    Serial.println(httpCode);

    delay(300); // Pausa entre envios para não sobrecarregar o Google
  }

  f.close(); // Fecha o arquivo CSV

  Serial.print("Sincronizacao concluida: ");
  Serial.print(enviadas);
  Serial.print("/");
  Serial.println(total);
}

// ============================================================
// CRIAR ARQUIVO DO DIA NO BOOT
// Cria o CSV do dia atual com cabeçalho se ainda não existir
// ============================================================

void criarArquivoDia() {

  char data[11];
  char horario[9];

  if (!obterDataHora(data, horario)) {
    return; // Sem hora disponível
  }

  char nomeArquivo[30];
  montarNomeArquivo(data, nomeArquivo);

  if (!SD.exists(nomeArquivo)) {
    dataFile = SD.open(nomeArquivo, FILE_WRITE); // Cria arquivo novo
    if (dataFile) {
      dataFile.print("Horario");
      for (int i = 1; i <= NUM_SENSORES; i++) {
        dataFile.print(";Sensor ");
        dataFile.print(i);
      }
      dataFile.println();
      dataFile.close();
      Serial.print("Arquivo do dia criado: ");
      Serial.println(nomeArquivo);
    }
  }
  else {
    Serial.print("Arquivo ja existe: ");
    Serial.println(nomeArquivo); // Arquivo já existe, nada a fazer
  }
}

// ============================================================
// CONECTAR WIFI
// Tenta conectar até 40 vezes (40 segundos)
// ============================================================

void conectarWiFi() {

  Serial.println("Conectando WiFi");
  lcd.clear();
  lcd.setCursor(0, 0);
  lcd.print("Conectando WiFi");

  WiFi.disconnect(true); // Limpa conexões anteriores
  WiFi.mode(WIFI_STA);   // Modo estação (cliente WiFi)
  delay(1000);

  WiFi.begin(ssid, password); // Inicia conexão

  int tentativas = 0;

  while (WiFi.status() != WL_CONNECTED && tentativas < 40) {
    delay(1000);   // Aguarda 1 segundo
    Serial.print(".");
    tentativas++;
  }

  if (WiFi.status() == WL_CONNECTED) {
    Serial.println();
    Serial.println("WiFi conectado");
    Serial.print("IP: ");
    Serial.println(WiFi.localIP()); // Exibe IP obtido
    lcd.setCursor(0, 1);
    lcd.print("WiFi OK         ");
  }
  else {
    Serial.println();
    Serial.println("Falha WiFi"); // Não conectou no tempo limite
    lcd.setCursor(0, 1);
    lcd.print("Falha WiFi      ");
  }

  delay(1500); // Pausa para exibir mensagem no LCD
}

// ============================================================
// ENVIAR MENSAGEM NO TELEGRAM
// Só envia se WiFi estiver conectado
// ============================================================

void enviarTelegram(String mensagem) {

  if (WiFi.status() != WL_CONNECTED) {
    return; // Sem WiFi, ignora
  }

  WiFiClientSecure client;
  client.setInsecure(); // Aceita SSL sem validação

  HTTPClient http;

  mensagem.replace(" ", "%20");  // Encode espaços
  mensagem.replace("\n", "%0A"); // Encode quebra de linha

  // Monta URL da API do Telegram com bot token, chat id e mensagem
  String url = String("https://api.telegram.org/bot") +
               String(BOT_TOKEN) +
               "/sendMessage?chat_id=" +
               String(CHAT_ID) +
               "&text=" +
               mensagem;

  http.begin(client, url);

  int httpCode = http.GET(); // Envia a mensagem

  Serial.print("Telegram HTTP: ");
  Serial.println(httpCode); // 200 = sucesso

  http.end();
}
